/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author comp
 */
package gayatri;

import static java.lang.Math.random;
import java.util.Random;
public class randomnum {
 private  int randomnum;
    public   int getrandomnum()
  {
   Random random=new Random(); 
     randomnum=10000+random.nextInt(1000);
return randomnum;
  }

    public int getRandomnum() {
        return randomnum;
    }

    public void setRandomnum(int randomnum) {
        this.randomnum = randomnum;
    }

  


}
